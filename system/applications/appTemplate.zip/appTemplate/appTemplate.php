<?php
class application_appTemplate extends application
{
	public $hasAuthentication=true;
	public $useBreadcrumbs=true;
		
	function initiate()
	{
		;
		return true;
	}
	
	public function eventmap()
	{
		
		return true;
	}
	
	public function sitemap()
	{
		$this->sitemap->page('|home');
		
		return true;
	}
}
?>